window.RUNTIME_ENV = {
  REACT_APP_SERVERURL: "https://esign.rapidlodge.com.au/api/app",
};
